# Nimap Infotech Machine Test - Java Spring Boot

This is a small project made for the Nimap Infotech machine test. It is built using Spring Boot and MySQL database.

## Requirements

- Java 8 or above
- MySQL
- Spring Boot
- Maven
- Postman (for testing the APIs)

## About the Project

This project has two main modules:

1. **Category**
2. **Product**

Each Category can have multiple Products (One-To-Many relationship).

### Features:

- CRUD operations for Category and Product
- Pagination for listing categories and products
- While getting a product by ID, its category details are also shown

## How to Run

1. Open MySQL Workbench and create a database:

   ```sql
   CREATE DATABASE nimaptask;
   ```
