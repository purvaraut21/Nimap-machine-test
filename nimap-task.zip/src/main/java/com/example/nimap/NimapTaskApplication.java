// This line defines the package structure
package com.example.nimap;

// Spring framework features for REST APIs, DI, etc.
import org.springframework.boot.SpringApplication;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// Class definition starts here
public class NimapTaskApplication {
    public static void main(String[] args) {
        SpringApplication.run(NimapTaskApplication.class, args);
    }
}
