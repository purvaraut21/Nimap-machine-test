// This line defines the package structure
package com.example.nimap.controller;

// Import model classes
import com.example.nimap.model.Product;
// Import service classes
import com.example.nimap.service.ProductService;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.beans.factory.annotation.Autowired;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.data.domain.Page;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.data.domain.PageRequest;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.web.bind.annotation.*;

// Marks this class as a REST API controller
@RestController
// Base URL mapping for this controller
@RequestMapping("/api/products")
// Class definition starts here
public class ProductController {

// Automatically inject the required dependency
    @Autowired
    private ProductService service;

// Handle HTTP GET request
    @GetMapping
    public Page<Product> getAll(@RequestParam(defaultValue = "0") int page) {
        return service.getAll(PageRequest.of(page, 5));
    }

// Handle HTTP GET request
    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) {
        return service.getById(id).orElseThrow();
    }

// Handle HTTP POST request
    @PostMapping
    public Product create(@RequestBody Product product) {
        return service.create(product);
    }

// Handle HTTP PUT request
    @PutMapping("/{id}")
    public Product update(@PathVariable Long id, @RequestBody Product product) {
        return service.update(id, product);
    }

// Handle HTTP DELETE request
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
