// This line defines the package structure
package com.example.nimap.model;

// JPA annotations for entity and database mapping
import jakarta.persistence.*;
import java.util.List;

// Marks this class as a database entity
@Entity
// Class definition starts here
public class Category {
// Primary key of the table
    @Id
// Auto-generates the primary key value
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
    private List<Product> products;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<Product> getProducts() { return products; }
    public void setProducts(List<Product> products) { this.products = products; }
}
