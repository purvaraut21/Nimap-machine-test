// This line defines the package structure
package com.example.nimap.model;

// JPA annotations for entity and database mapping
import jakarta.persistence.*;

// Marks this class as a database entity
@Entity
// Class definition starts here
public class Product {
// Primary key of the table
    @Id
// Auto-generates the primary key value
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private double price;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
}
