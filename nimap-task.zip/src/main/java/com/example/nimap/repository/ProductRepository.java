// This line defines the package structure
package com.example.nimap.repository;

// Import model classes
import com.example.nimap.model.Product;
// Import repository interfaces
import org.springframework.data.jpa.repository.JpaRepository;

// Interface definition starts here
public interface ProductRepository extends JpaRepository<Product, Long> {
}
