// This line defines the package structure
package com.example.nimap.service;

// Import model classes
import com.example.nimap.model.Category;
// Import repository interfaces
import com.example.nimap.repository.CategoryRepository;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.beans.factory.annotation.Autowired;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.data.domain.Page;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.data.domain.Pageable;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
// Class definition starts here
public class CategoryService {
// Automatically inject the required dependency
    @Autowired
    private CategoryRepository repo;

    public Page<Category> getAll(Pageable pageable) {
        return repo.findAll(pageable);
    }

    public Optional<Category> getById(Long id) {
        return repo.findById(id);
    }

    public Category create(Category category) {
        return repo.save(category);
    }

    public Category update(Long id, Category updated) {
        Category category = repo.findById(id).orElseThrow();
        category.setName(updated.getName());
        return repo.save(category);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
