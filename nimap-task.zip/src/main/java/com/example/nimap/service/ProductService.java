// This line defines the package structure
package com.example.nimap.service;

// Import model classes
import com.example.nimap.model.Product;
// Import repository interfaces
import com.example.nimap.repository.ProductRepository;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.beans.factory.annotation.Autowired;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.data.domain.Page;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.data.domain.Pageable;
// Spring framework features for REST APIs, DI, etc.
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
// Class definition starts here
public class ProductService {
// Automatically inject the required dependency
    @Autowired
    private ProductRepository repo;

    public Page<Product> getAll(Pageable pageable) {
        return repo.findAll(pageable);
    }

    public Optional<Product> getById(Long id) {
        return repo.findById(id);
    }

    public Product create(Product product) {
        return repo.save(product);
    }

    public Product update(Long id, Product updated) {
        Product product = repo.findById(id).orElseThrow();
        product.setName(updated.getName());
        product.setPrice(updated.getPrice());
        product.setCategory(updated.getCategory());
        return repo.save(product);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
